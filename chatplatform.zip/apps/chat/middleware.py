from urllib.parse import parse_qs
from channels.db import database_sync_to_async
from channels.middleware import BaseMiddleware
from django.contrib.auth.models import AnonymousUser
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import AccessToken


@database_sync_to_async
def get_user_from_token(token):
    """Resolves a JWT access token into a User instance."""
    from apps.accounts.models import User

    try:
        access_token = AccessToken(token)
        user_id = access_token['user_id']
        return User.objects.get(id=user_id)
    except (InvalidToken, TokenError, User.DoesNotExist):
        return AnonymousUser()


class JWTAuthMiddleware(BaseMiddleware):
    """
    Authentication middleware for WebSocket connections.
    
    Supports multiple authentication methods:
    1. Session cookie (for browser/HTMX) - handled by AuthMiddlewareStack
    2. JWT via query parameter (for mobile web views) - ?token=...
    3. JWT via Authorization header (for Postman, Flutter, mobile apps) - Bearer token
    
    This middleware runs AFTER channels.auth.AuthMiddlewareStack in asgi.py,
    so scope['user'] is already populated from session cookie for browser
    connections. If session already resolved a real user, this middleware
    does nothing — it only kicks in when scope['user'] is still Anonymous.
    """

    async def __call__(self, scope, receive, send):
        current_user = scope.get('user')

        # فقط اگر کاربر از طریق session احراز هویت نشده باشد
        if current_user is None or current_user.is_anonymous:
            token = None
            
            # 1️⃣ اول: از Query String دریافت کن (روش فعلی برای وب)
            query_params = parse_qs(scope['query_string'].decode())
            token = query_params.get('token', [None])[0]
            
            # 2️⃣ دوم: اگر در Query نبود، از Header Authorization دریافت کن
            if not token:
                headers = dict(scope.get('headers', []))
                auth_header = headers.get(b'authorization', b'').decode()
                
                # پشتیبانی از هر دو فرمت Bearer و Token
                if auth_header.startswith('Bearer '):
                    token = auth_header.split(' ')[1]
                elif auth_header.startswith('Token '):
                    token = auth_header.split(' ')[1]
            
            # 3️⃣ سوم: (اختیاری) از Cookie دریافت کن
            if not token:
                cookies = scope.get('cookies', {})
                token = cookies.get('token') or cookies.get('access_token')
            
            # اگر توکن پیدا شد، کاربر را احراز هویت کن
            if token:
                scope['user'] = await get_user_from_token(token)
            else:
                scope['user'] = AnonymousUser()

        return await super().__call__(scope, receive, send)