"""
Constants used across the entire project.
"""
# DOMAIN RULES
# Max length of a chat message body. Enforced in the send_message
# service so every transport (web view, DRF API, any future caller)
# shares the exact same limit — a single source of truth.
MAX_MESSAGE_LENGTH = 5000


# REALTIME BROADCASTS
PRESENCE_GROUP = 'presence_broadcasts'
BROADCAST_READ_RECEIPT = 'broadcast_read_receipt'
BROADCAST_NEW_MESSAGE = 'broadcast_new_message'
BROADCAST_TYPING = 'broadcast_typing'


# SOCKET EVENTS
BROADCAST_PRESENCE = 'presence'
READ_RECEIPT = 'read_receipt'
TYPING = 'typing'
NEW_MESSAGE = 'message.new'
BROADCAST_PRESENCE_UPDATE = 'presence.update'